"use client"

type ConfirmVariant = "danger" | "default"

interface ConfirmModalProps {
  open: boolean
  title: string
  message: string
  confirmLabel?: string
  cancelLabel?: string
  variant?: ConfirmVariant
  onConfirm: () => void
  onCancel: () => void
}

export default function ConfirmModal({
  open,
  title,
  message,
  confirmLabel = "Confirmar",
  cancelLabel = "Cancelar",
  variant = "default",
  onConfirm,
  onCancel
}: ConfirmModalProps) {
  if (!open) return null

  const titleColor =
    variant === "danger" ? "text-red-900" : "text-gray-900"

  const confirmClasses =
    variant === "danger"
      ? "bg-red-600 text-white hover:bg-red-700"
      : "bg-black text-white hover:opacity-90"

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-white rounded-2xl shadow-lg max-w-sm w-full mx-4 border">
        <div className="px-4 py-3 border-b">
          <h2 className={`text-sm font-semibold ${titleColor}`}>{title}</h2>
        </div>

        <div className="px-4 py-4 text-sm text-gray-700">
          <p>{message}</p>
        </div>

        <div className="px-4 py-3 border-t flex justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-3 py-1.5 rounded-2xl text-xs border hover:bg-gray-50"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`px-3 py-1.5 rounded-2xl text-xs font-medium ${confirmClasses}`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
