export default function DocentePage() {
  return (
    <main className="p-6">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Módulo do Docente</h1>
        <a href="/docente/processos/progressao/abrir" className="px-3 py-2 bg-black text-white rounded-xl hover:opacity-80">
          Abrir Processo
        </a>
      </header>

      <section className="space-y-2">
        <p>Bem-vindo ao módulo do Docente.</p>
        <p>Use o botão acima para abrir um processo de Progressão/Promoção.</p>
      </section>
    </main>
  )
}
