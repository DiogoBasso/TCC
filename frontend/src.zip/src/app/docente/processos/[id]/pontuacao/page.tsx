"use client"

import { useEffect, useState, useCallback } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import Modal from "@/components/Modal"

type ProcessType = "PROGRESSAO" | "PROMOCAO"

type ProcessStatus =
  | "DRAFT"
  | "SUBMITTED"
  | "UNDER_REVIEW"
  | "RETURNED"
  | "APPROVED"
  | "REJECTED"

type ModalVariant = "success" | "error" | "info"

type ModalState = {
  open: boolean
  title: string
  message: string
  variant: ModalVariant
}

type ApiResponse<T> = {
  status: string
  message: string
  data: T | null
}

type Evidence = {
  evidenceFileId: number
  originalName: string
  url: string
  mimeType: string | null
  sizeBytes: number | null
}

type CurrentScore = {
  processScoreId: number
  quantity: number
  awardedPoints: string
  evidences: Evidence[]
}

type ScoringItem = {
  itemId: number
  description: string
  unit: string | null
  points: string | number
  hasMaxPoints: boolean
  maxPoints?: string | number | null
  active: boolean
  currentScore: CurrentScore | null
}

type BlockNode = {
  nodeId: number
  name: string
  code: string | null
  parentId: number | null
  sortOrder: number
  items: ScoringItem[]
}

type EstruturaPontuacao = {
  processId: number
  scoringTableId: number
  type: ProcessType
  status: ProcessStatus
  blocks: BlockNode[]
}

type TreeNode = {
  nodeId: number
  name: string
  code: string | null
  parentId: number | null
  sortOrder: number
  items: ScoringItem[]
  children: TreeNode[]
}

type UserEvidenceFile = {
  evidenceFileId: number
  originalName: string
  url: string
  mimeType: string | null
  sizeBytes: number | null
  uploadedAt: string
}

type EvidenceModalMode = "attachRequired" | "change"

type EvidenceModalState = {
  open: boolean
  itemId: number | null
  mode: EvidenceModalMode
  existingEvidence: Evidence | null
  files: UserEvidenceFile[]
  loading: boolean
}

type PendingScore = {
  itemId: number
  quantity: number
  awardedPoints: string
}

// respostas do backend
type SaveScoreResponse = {
  processId: number
  itemId: number
  processScoreId: number
  quantity: number
  awardedPoints: string
  evidence: {
    evidenceFileId: number
    originalName: string
    url: string
    mimeType: string | null
    sizeBytes: number | null
  } | null
}

type EvidenceUpdateResponse = {
  processScoreId: number
  itemId: number
  evidence: {
    evidenceFileId: number
    originalName: string
    url: string
    mimeType: string | null
    sizeBytes: number | null
  }
}

// ícones simples em SVG
function EyeIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
      <path
        d="M12 5C7 5 2.73 8.11 1 12c1.73 3.89 6 7 11 7s9.27-3.11 11-7c-1.73-3.89-6-7-11-7Zm0 11a4 4 0 1 1 0-8 4 4 0 0 1 0 8Z"
        fill="currentColor"
      />
    </svg>
  )
}

function FileSwapIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
      <path
        d="M8 3h6l5 5v11a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm5 1.5V9h4.5L13 4.5ZM9 13h6v1.5H9V13Zm0 3h4v1.5H9V16Z"
        fill="currentColor"
      />
    </svg>
  )
}

// helper pra atualizar item recursivamente na árvore
function updateItemInTree(
  nodes: TreeNode[],
  itemId: number,
  updater: (item: ScoringItem) => ScoringItem
): TreeNode[] {
  return nodes.map(node => ({
    ...node,
    items: node.items.map(item =>
      item.itemId === itemId ? updater(item) : item
    ),
    children: updateItemInTree(node.children, itemId, updater)
  }))
}

function statusLabel(status: ProcessStatus) {
  switch (status) {
    case "DRAFT":
      return "Rascunho"
    case "SUBMITTED":
      return "Submetido"
    case "UNDER_REVIEW":
      return "Em análise"
    case "RETURNED":
      return "Devolvido"
    case "APPROVED":
      return "Aprovado"
    case "REJECTED":
      return "Indeferido"
    default:
      return status
  }
}

function badgeColor(status: ProcessStatus) {
  if (status === "APPROVED") return "bg-emerald-100 text-emerald-800"
  if (status === "REJECTED") return "bg-red-100 text-red-800"
  if (status === "RETURNED") return "bg-amber-100 text-amber-800"
  if (status === "UNDER_REVIEW") return "bg-blue-100 text-blue-800"
  if (status === "SUBMITTED") return "bg-slate-100 text-slate-800"
  return "bg-gray-100 text-gray-700"
}

function formatPoints(value: string | number | null | undefined) {
  if (value === null || value === undefined) return ""
  const num = Number(value)
  if (Number.isNaN(num)) return String(value)
  return num.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })
}

export default function ProcessoPontuacaoPage() {
  const params = useParams()
  const id = (params as any)?.id as string | undefined

  const [estrutura, setEstrutura] = useState<EstruturaPontuacao | null>(null)
  const [treeRoots, setTreeRoots] = useState<TreeNode[]>([])
  const [loading, setLoading] = useState(true)
  const [savingItemId, setSavingItemId] = useState<number | null>(null)
  const [uploadingItemId, setUploadingItemId] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)

  const [modal, setModal] = useState<ModalState>({
    open: false,
    title: "",
    message: "",
    variant: "info"
  })

  const [activeItemId, setActiveItemId] = useState<number | null>(null)
  const [pendingScore, setPendingScore] = useState<PendingScore | null>(null)

  const [evidenceModal, setEvidenceModal] = useState<EvidenceModalState>({
    open: false,
    itemId: null,
    mode: "change",
    existingEvidence: null,
    files: [],
    loading: false
  })

  const [previewEvidence, setPreviewEvidence] = useState<Evidence | null>(null)

  const [itemForm, setItemForm] = useState<
    Record<
      number,
      {
        quantity: string
        awardedPoints: string
      }
    >
  >({})

  function openModal(payload: Omit<ModalState, "open">) {
    setModal({
      open: true,
      ...payload
    })
  }

  function closeModal() {
    setModal(prev => ({ ...prev, open: false }))
  }

  function buildTree(blocks: BlockNode[]): TreeNode[] {
    const map = new Map<number, TreeNode>()

    blocks.forEach(b => {
      map.set(b.nodeId, {
        nodeId: b.nodeId,
        name: b.name,
        code: b.code,
        parentId: b.parentId,
        sortOrder: b.sortOrder,
        items: b.items,
        children: []
      })
    })

    const roots: TreeNode[] = []

    map.forEach(node => {
      if (node.parentId === null || node.parentId === undefined) {
        roots.push(node)
      } else {
        const parent = map.get(node.parentId)
        if (parent) {
          parent.children.push(node)
        } else {
          roots.push(node)
        }
      }
    })

    const sortTree = (nodes: TreeNode[]) => {
      nodes.sort((a, b) => a.sortOrder - b.sortOrder)
      nodes.forEach(n => sortTree(n.children))
    }

    sortTree(roots)
    return roots
  }

  const carregarEstrutura = useCallback(async () => {
    if (!id) return

    setLoading(true)
    setError(null)

    try {
      const r = await fetch(`/api/processos/${id}/pontuacao/estrutura`, {
        method: "GET",
        credentials: "include"
      })

      const json = (await r.json().catch(() => null)) as ApiResponse<EstruturaPontuacao>

      if (!r.ok) {
        setError(json?.message || "Erro ao carregar estrutura de pontuação")
        setEstrutura(null)
        setTreeRoots([])
        return
      }

      if (!json?.data) {
        setError("Estrutura de pontuação não encontrada")
        setEstrutura(null)
        setTreeRoots([])
        return
      }

      const data = json.data
      setEstrutura(data)

      const tree = buildTree(data.blocks)
      setTreeRoots(tree)

      const formState: typeof itemForm = {}
      data.blocks.forEach(block => {
        block.items.forEach(item => {
          const current = item.currentScore
          formState[item.itemId] = {
            quantity: current ? String(current.quantity) : "",
            awardedPoints: current ? String(current.awardedPoints) : ""
          }
        })
      })
      setItemForm(formState)
    } catch (e: any) {
      setError(e?.message || "Erro inesperado ao carregar estrutura de pontuação")
      setEstrutura(null)
      setTreeRoots([])
    } finally {
      setLoading(false)
    }
  }, [id])

  useEffect(() => {
    carregarEstrutura()
  }, [carregarEstrutura])

  const canEditScores =
    estrutura &&
    (estrutura.status === "DRAFT" ||
      estrutura.status === "RETURNED" ||
      estrutura.status === "REJECTED")

  async function loadUserEvidenceFiles() {
    try {
      const r = await fetch("/api/evidencias/arquivos", {
        method: "GET",
        credentials: "include"
      })

      const json = (await r.json().catch(() => null)) as ApiResponse<
        UserEvidenceFile[]
      >

      if (!r.ok) {
        openModal({
          title: "Erro ao carregar arquivos",
          message:
            json?.message ||
            "Não foi possível listar os arquivos de evidência já enviados.",
          variant: "error"
        })
        return []
      }

      return json.data || []
    } catch (e: any) {
      openModal({
        title: "Erro ao carregar arquivos",
        message:
          e?.message ||
          "Ocorreu um erro inesperado ao buscar os arquivos de evidência.",
        variant: "error"
      })
      return []
    }
  }

  async function openEvidenceModalForItem(
    itemId: number,
    mode: EvidenceModalMode,
    existingEvidence: Evidence | null
  ) {
    setEvidenceModal({
      open: true,
      itemId,
      mode,
      existingEvidence,
      files: [],
      loading: true
    })

    const files = await loadUserEvidenceFiles()

    setEvidenceModal(prev => ({
      ...prev,
      files,
      loading: false
    }))
  }

  function closeEvidenceModal() {
    setEvidenceModal(prev => ({
      ...prev,
      open: false,
      itemId: null,
      existingEvidence: null
    }))
  }

  function handleChangeQuantity(item: ScoringItem, value: string) {
    if (!canEditScores) return

    if (activeItemId !== null && activeItemId !== item.itemId) {
      openModal({
        title: "Finalize o item atual",
        message:
          "Conclua o preenchimento (salvar pontuação e anexar comprovante) do item em edição antes de iniciar outro.",
        variant: "info"
      })
      return
    }

    if (activeItemId === null) {
      setActiveItemId(item.itemId)
    }

    setItemForm(prev => {
      const prevItem = prev[item.itemId] || { quantity: "", awardedPoints: "" }

      if (item.hasMaxPoints) {
        return {
          ...prev,
          [item.itemId]: {
            ...prevItem,
            quantity: value
          }
        }
      }

      const quantityNumber =
        value === "" || value === null ? 0 : Number(value)

      let newPoints = 0
      if (!Number.isNaN(quantityNumber) && quantityNumber >= 0) {
        const base = Number(item.points)
        if (!Number.isNaN(base)) {
          newPoints = quantityNumber * base
        }
      }

      return {
        ...prev,
        [item.itemId]: {
          quantity: value,
          awardedPoints: newPoints.toFixed(2)
        }
      }
    })
  }

  function handleChangePoints(item: ScoringItem, value: string) {
    if (!canEditScores) return

    const itemId = item.itemId

    if (activeItemId !== null && activeItemId !== itemId) {
      openModal({
        title: "Finalize o item atual",
        message:
          "Conclua o preenchimento (salvar pontuação e anexar comprovante) do item em edição antes de iniciar outro.",
        variant: "info"
      })
      return
    }

    if (activeItemId === null) {
      setActiveItemId(itemId)
    }

    // agora não ajustamos mais automaticamente, só guardamos o valor digitado
    setItemForm(prev => ({
      ...prev,
      [itemId]: {
        quantity: prev[itemId]?.quantity ?? "",
        awardedPoints: value
      }
    }))
  }

  function handleCancelItemEdition(item: ScoringItem) {
    setItemForm(prev => ({
      ...prev,
      [item.itemId]: {
        quantity: item.currentScore ? String(item.currentScore.quantity) : "",
        awardedPoints: item.currentScore
          ? String(item.currentScore.awardedPoints)
          : ""
      }
    }))

    setPendingScore(prev => (prev && prev.itemId === item.itemId ? null : prev))

    setActiveItemId(null)
  }

  // atualiza só um item na estrutura e na árvore depois de salvar pontuação
  function applySavedScoreToState(itemId: number, data: SaveScoreResponse) {
    const newEvidenceArray: Evidence[] =
      data.evidence != null
        ? [
            {
              evidenceFileId: data.evidence.evidenceFileId,
              originalName: data.evidence.originalName,
              url: data.evidence.url,
              mimeType: data.evidence.mimeType,
              sizeBytes: data.evidence.sizeBytes
            }
          ]
        : []

    // estrutura (meta)
    setEstrutura(prev => {
      if (!prev) return prev

      return {
        ...prev,
        blocks: prev.blocks.map(block => ({
          ...block,
          items: block.items.map(i => {
            if (i.itemId !== itemId) return i

            const existingEvidence =
              data.evidence != null
                ? newEvidenceArray
                : i.currentScore?.evidences ?? []

            return {
              ...i,
              currentScore: {
                processScoreId: data.processScoreId,
                quantity: data.quantity,
                awardedPoints: data.awardedPoints,
                evidences: existingEvidence
              }
            }
          })
        }))
      }
    })

    // árvore usada na tela
    setTreeRoots(prev =>
      updateItemInTree(prev, itemId, i => {
        const existingEvidence =
          data.evidence != null
            ? newEvidenceArray
            : i.currentScore?.evidences ?? []

        return {
          ...i,
          currentScore: {
            processScoreId: data.processScoreId,
            quantity: data.quantity,
            awardedPoints: data.awardedPoints,
            evidences: existingEvidence
          }
        }
      })
    )

    setItemForm(prev => ({
      ...prev,
      [itemId]: {
        quantity: String(data.quantity),
        awardedPoints: String(data.awardedPoints)
      }
    }))
  }

  // atualiza só evidência de um item (estrutura + árvore)
  function applyEvidenceUpdateToState(itemId: number, data: EvidenceUpdateResponse) {
    const newEvidence: Evidence = {
      evidenceFileId: data.evidence.evidenceFileId,
      originalName: data.evidence.originalName,
      url: data.evidence.url,
      mimeType: data.evidence.mimeType,
      sizeBytes: data.evidence.sizeBytes
    }

    setEstrutura(prev => {
      if (!prev) return prev

      return {
        ...prev,
        blocks: prev.blocks.map(block => ({
          ...block,
          items: block.items.map(i => {
            if (i.itemId !== itemId) return i

            const current = i.currentScore
            if (current) {
              return {
                ...i,
                currentScore: {
                  ...current,
                  processScoreId: data.processScoreId,
                  evidences: [newEvidence]
                }
              }
            }

            return {
              ...i,
              currentScore: {
                processScoreId: data.processScoreId,
                quantity: 0,
                awardedPoints: "0.00",
                evidences: [newEvidence]
              }
            }
          })
        }))
      }
    })

    setTreeRoots(prev =>
      updateItemInTree(prev, itemId, i => {
        const current = i.currentScore
        if (current) {
          return {
            ...i,
            currentScore: {
              ...current,
              processScoreId: data.processScoreId,
              evidences: [newEvidence]
            }
          }
        }

        return {
          ...i,
          currentScore: {
            processScoreId: data.processScoreId,
            quantity: 0,
            awardedPoints: "0.00",
            evidences: [newEvidence]
          }
        }
      })
    )
  }

  async function salvarPontuacaoFinal(
    itemId: number,
    quantityNumber: number,
    awardedPointsToSend: string
  ) {
    if (!estrutura || !id) return

    setSavingItemId(itemId)

    try {
      const r = await fetch(`/api/processos/${id}/itens/${itemId}/pontuacao`, {
        method: "PATCH",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          quantity: quantityNumber,
          awardedPoints: awardedPointsToSend
        })
      })

      const json = (await r.json().catch(() => null)) as ApiResponse<
        SaveScoreResponse
      >

      if (!r.ok) {
        openModal({
          title: "Erro ao salvar pontuação",
          message: json?.message || "Não foi possível salvar a pontuação deste item.",
          variant: "error"
        })
        return
      }

      if (json?.data) {
        applySavedScoreToState(itemId, json.data)
      }

      openModal({
        title: "Pontuação salva",
        message: "Pontuação do item salva com sucesso.",
        variant: "success"
      })

      setActiveItemId(null)
      setPendingScore(prev => (prev && prev.itemId === itemId ? null : prev))
    } catch (e: any) {
      openModal({
        title: "Erro inesperado",
        message: e?.message || "Ocorreu um erro ao salvar a pontuação.",
        variant: "error"
      })
    } finally {
      setSavingItemId(null)
    }
  }

  async function handleSalvarItem(itemId: number) {
    if (!estrutura || !id) return

    const item = estrutura.blocks.flatMap(b => b.items).find(i => i.itemId === itemId)
    if (!item) {
      openModal({
        title: "Erro",
        message: "Item de pontuação não encontrado na estrutura.",
        variant: "error"
      })
      return
    }

    const form = itemForm[itemId] || { quantity: "", awardedPoints: "" }

    let quantityNumber = 0
    let awardedPointsToSend = "0"
    let finalPointsNumber = 0

    if (item.hasMaxPoints) {
      const pointsNumber =
        form.awardedPoints === "" || form.awardedPoints === null
          ? 0
          : Number(form.awardedPoints)

      if (Number.isNaN(pointsNumber) || pointsNumber < 0) {
        openModal({
          title: "Valor inválido",
          message: "Informe um valor numérico válido para a pontuação.",
          variant: "error"
        })
        return
      }

      // validação de máximo SEM ajustar automaticamente
      let maxAllowed: number | null = null
      if (item.maxPoints !== null && item.maxPoints !== undefined) {
        maxAllowed = Number(item.maxPoints)
      } else if (item.points !== null && item.points !== undefined) {
        maxAllowed = Number(item.points)
      }

      if (
        maxAllowed !== null &&
        !Number.isNaN(maxAllowed) &&
        pointsNumber > maxAllowed
      ) {
        openModal({
          title: "Pontuação acima do permitido",
          message:
            "O valor informado ultrapassa o máximo permitido para este item. Por favor, revise e ajuste a pontuação antes de salvar.",
          variant: "error"
        })
        return
      }

      quantityNumber = 0
      finalPointsNumber = pointsNumber
      awardedPointsToSend = pointsNumber.toFixed(2)
    } else {
      quantityNumber =
        form.quantity === "" || form.quantity === null ? 0 : Number(form.quantity)

      if (Number.isNaN(quantityNumber) || quantityNumber < 0) {
        openModal({
          title: "Valor inválido",
          message: "Informe uma quantidade numérica maior ou igual a zero.",
          variant: "error"
        })
        return
      }

      const base = Number(item.points)
      const autoPoints =
        !Number.isNaN(base) && quantityNumber >= 0 ? quantityNumber * base : 0

      finalPointsNumber = autoPoints
      awardedPointsToSend = autoPoints.toFixed(2)
    }

    const hasEvidence =
      item.currentScore &&
      item.currentScore.evidences &&
      item.currentScore.evidences.length > 0

    if (finalPointsNumber > 0 && !hasEvidence) {
      setPendingScore({
        itemId,
        quantity: quantityNumber,
        awardedPoints: awardedPointsToSend
      })

      await openEvidenceModalForItem(itemId, "attachRequired", null)

      return
    }

    await salvarPontuacaoFinal(itemId, quantityNumber, awardedPointsToSend)
  }

  async function handleUploadEvidenceFromModal(file: File | null) {
    if (!file || !estrutura || !id || !evidenceModal.itemId) return

    const itemId = evidenceModal.itemId
    setUploadingItemId(itemId)

    try {
      const formData = new FormData()
      formData.append("file", file)

      const r = await fetch(
        `/api/processos/${id}/pontuacao/itens/${itemId}/evidencias`,
        {
          method: "POST",
          credentials: "include",
          body: formData
        }
      )

      const json = (await r.json().catch(() => null)) as ApiResponse<
        EvidenceUpdateResponse
      >

      if (!r.ok) {
        openModal({
          title: "Erro ao anexar evidência",
          message: json?.message || "Não foi possível anexar o arquivo.",
          variant: "error"
        })
        return
      }

      if (json?.data) {
        applyEvidenceUpdateToState(itemId, json.data)
      }

      if (pendingScore && pendingScore.itemId === itemId) {
        await salvarPontuacaoFinal(
          pendingScore.itemId,
          pendingScore.quantity,
          pendingScore.awardedPoints
        )
      }

      closeEvidenceModal()
    } catch (e: any) {
      openModal({
        title: "Erro inesperado",
        message: e?.message || "Ocorreu um erro ao anexar o arquivo.",
        variant: "error"
      })
    } finally {
      setUploadingItemId(null)
    }
  }

  async function handleReuseEvidenceFromModal(fileId: number) {
    if (!estrutura || !id || !evidenceModal.itemId) return

    const itemId = evidenceModal.itemId
    setUploadingItemId(itemId)

    try {
      const r = await fetch(
        `/api/processos/${id}/pontuacao/itens/${itemId}/evidencias/reusar`,
        {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ evidenceFileId: fileId })
        }
      )

      const json = (await r.json().catch(() => null)) as ApiResponse<
        EvidenceUpdateResponse
      >

      if (!r.ok) {
        openModal({
          title: "Erro ao reutilizar evidência",
          message: json?.message || "Não foi possível reutilizar este arquivo.",
          variant: "error"
        })
        return
      }

      if (json?.data) {
        applyEvidenceUpdateToState(itemId, json.data)
      }

      if (pendingScore && pendingScore.itemId === itemId) {
        await salvarPontuacaoFinal(
          pendingScore.itemId,
          pendingScore.quantity,
          pendingScore.awardedPoints
        )
      }

      closeEvidenceModal()
    } catch (e: any) {
      openModal({
        title: "Erro inesperado",
        message: e?.message || "Ocorreu um erro ao vincular o arquivo.",
        variant: "error"
      })
    } finally {
      setUploadingItemId(null)
    }
  }

  function renderItemRow(item: ScoringItem) {
    const form = itemForm[item.itemId] || {
      quantity: "",
      awardedPoints: ""
    }

    const hasEvidence =
      item.currentScore &&
      item.currentScore.evidences &&
      item.currentScore.evidences.length > 0

    const evidence = hasEvidence ? item.currentScore!.evidences[0] : null

    const isMaxItem = item.hasMaxPoints

    const maxValueRaw =
      item.maxPoints !== null && item.maxPoints !== undefined
        ? item.maxPoints
        : item.hasMaxPoints
        ? item.points
        : null

    const maxValue =
      maxValueRaw !== null && maxValueRaw !== undefined
        ? Number(maxValueRaw)
        : null

    const maxLabel =
      maxValue !== null && !Number.isNaN(maxValue)
        ? formatPoints(maxValue)
        : null

    const previewPoints =
      !isMaxItem && form.awardedPoints
        ? formatPoints(form.awardedPoints)
        : isMaxItem && form.awardedPoints
        ? formatPoints(form.awardedPoints)
        : "0,00"

    const isLockedByAnother =
      activeItemId !== null && activeItemId !== item.itemId

    const isThisActive = activeItemId === item.itemId

    const hasScore =
      item.currentScore &&
      (Number(item.currentScore.awardedPoints) > 0 ||
        Number(item.currentScore.quantity) > 0)

    const showEvidenceArea = Boolean(hasScore)

    // flag: valor acima do máximo para itens com máximo
    let exceedsMax = false
    if (isMaxItem && maxValue !== null && !Number.isNaN(maxValue)) {
      const numeric = Number(form.awardedPoints)
      if (!Number.isNaN(numeric) && numeric > maxValue) {
        exceedsMax = true
      }
    }

    return (
      <div
        key={item.itemId}
        className={
          "border rounded-2xl p-3 bg-slate-50 flex flex-col gap-2 " +
          (isThisActive ? "border-blue-400 shadow-sm" : "")
        }
      >
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-2">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <div className="text-sm font-medium text-gray-800">
                {item.description}
              </div>

              {hasScore && !isThisActive && (
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-medium px-2 py-0.5 border border-emerald-100">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  Item preenchido
                </span>
              )}

              {isThisActive && (
                <span className="inline-flex items-center gap-1 rounded-full bg-blue-50 text-blue-700 text-[10px] font-medium px-2 py-0.5 border border-blue-100">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                  Em edição
                </span>
              )}
            </div>

            {!isMaxItem && (
              <div className="text-xs text-gray-500">
                <span className="font-medium">
                  {formatPoints(item.points)}
                </span>{" "}
                {Number(item.points) > 1 ? "pontos" : "ponto"} para cada{" "}
                <span className="font-medium">
                  {item.unit || "unidade"}
                </span>
              </div>
            )}

            {isMaxItem && maxLabel && (
              <div
                className={
                  "text-xs " +
                  (exceedsMax ? "text-red-600 font-medium" : "text-gray-500")
                }
              >
                Pontuação máxima neste item:{" "}
                <span className="font-medium">{maxLabel} pontos</span>.
              </div>
            )}

            {isThisActive && (
              <div className="text-[11px] text-blue-600">
                Você está preenchendo este item. Salve a pontuação e anexe o
                comprovante antes de iniciar outro.
              </div>
            )}

            {isMaxItem && exceedsMax && (
              <div className="text-[11px] text-red-600">
                Valor informado ultrapassa o máximo permitido para este item.
              </div>
            )}
          </div>

          <div className="flex flex-col gap-2 w-full md:w-72">
            {!isMaxItem && (
              <>
                <div className="flex gap-2">
                  <div className="flex-1">
                    <label className="block text-[11px] text-gray-500 mb-1">
                      Quantidade
                    </label>
                    <input
                      type="number"
                      min={0}
                      className="w-full border rounded-xl px-2 py-1.5 text-sm"
                      value={form.quantity}
                      onChange={e =>
                        handleChangeQuantity(item, e.target.value)
                      }
                      disabled={
                        !canEditScores ||
                        savingItemId === item.itemId ||
                        isLockedByAnother
                      }
                    />
                  </div>
                </div>

                <div className="text-xs text-gray-700 bg-white border rounded-xl px-2 py-1.5">
                  <span className="font-medium">Pontos calculados: </span>
                  <span className="font-semibold">
                    {previewPoints || "0,00"}
                  </span>
                </div>
              </>
            )}

            {isMaxItem && (
              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="block text-[11px] text-gray-500 mb-1">
                    Pontos (até {maxLabel ?? "o máximo definido"})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    className={
                      "w-full border rounded-xl px-2 py-1.5 text-sm " +
                      (exceedsMax
                        ? "border-red-400 text-red-700 bg-red-50"
                        : "")
                    }
                    value={form.awardedPoints}
                    onChange={e =>
                      handleChangePoints(item, e.target.value)
                    }
                    disabled={
                      !canEditScores ||
                      savingItemId === item.itemId ||
                      isLockedByAnother
                    }
                  />
                </div>
              </div>
            )}

            {isThisActive && hasScore && item.currentScore && (
              <div className="text-[11px] text-gray-500">
                <span className="font-medium">Pontos já gravados: </span>
                {formatPoints(item.currentScore.awardedPoints) || "0,00"}
              </div>
            )}

            {isThisActive && (
              <button
                type="button"
                onClick={() => handleSalvarItem(item.itemId)}
                disabled={
                  !canEditScores ||
                  savingItemId === item.itemId ||
                  isLockedByAnother
                }
                className="w-full mt-1 px-3 py-1.5 rounded-2xl bg-black text-white text-xs font-medium disabled:opacity-50"
              >
                {savingItemId === item.itemId ? "Salvando..." : "Salvar pontuação"}
              </button>
            )}

            {isThisActive && (
              <button
                type="button"
                className="w-full mt-1 px-3 py-1.5 rounded-2xl border border-red-300 text-red-700 text-xs font-medium hover:bg-red-50"
                onClick={() => handleCancelItemEdition(item)}
              >
                Cancelar edição deste item
              </button>
            )}
          </div>
        </div>

        {showEvidenceArea && (
          <div className="border-t pt-2 mt-1 flex flex-col md:flex-row md:items-center md:justify-between gap-2">
            <div className="text-xs text-gray-600">
              {evidence && (
                <button
                  type="button"
                  className="inline-flex items-center justify-center gap-1 text-[11px] px-3 py-1 rounded-full border border-gray-300 hover:bg-gray-50"
                  onClick={() => setPreviewEvidence(evidence)}
                >
                  <EyeIcon className="w-3 h-3" />
                  <span>Visualizar comprovante</span>
                </button>
              )}
            </div>

            <div className="flex flex-col md:flex-row md:items-center gap-2">
              {evidence && (
                <button
                  type="button"
                  className="inline-flex items-center justify-center gap-1 px-3 py-1 rounded-full border border-gray-300 text-[11px] font-medium hover:bg-gray-50"
                  onClick={() =>
                    openEvidenceModalForItem(item.itemId, "change", evidence)
                  }
                  disabled={!canEditScores || isLockedByAnother}
                >
                  <FileSwapIcon className="w-3 h-3" />
                  <span>Alterar comprovante</span>
                </button>
              )}

              {!evidence && (
                <button
                  type="button"
                  className="inline-flex items-center justify-center gap-1 px-3 py-1 rounded-full border border-gray-300 text-[11px] font-medium hover:bg-gray-50"
                  onClick={() =>
                    openEvidenceModalForItem(item.itemId, "change", null)
                  }
                  disabled={!canEditScores || isLockedByAnother}
                >
                  <FileSwapIcon className="w-3 h-3" />
                  <span>Anexar comprovante</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    )
  }

  function renderNode(node: TreeNode) {
    const nodeLabel = node.code ? `${node.code} - ${node.name}` : node.name

    return (
      <div key={node.nodeId} className="space-y-3">
        <div className="bg-white border rounded-2xl p-4 shadow-sm">
          <div className="flex justify-between items-center gap-2 mb-3">
            <div>
              <div className="text-sm font-semibold text-gray-800">
                {nodeLabel}
              </div>
            </div>
          </div>

          {node.items.length > 0 && (
            <div className="space-y-2">
              {node.items.map(item => renderItemRow(item))}
            </div>
          )}

          {node.children.length > 0 && (
            <div className="mt-4 border-l-2 border-dashed border-gray-200 pl-4 space-y-4">
              {node.children.map(child => renderNode(child))}
            </div>
          )}

          {node.items.length === 0 && node.children.length === 0 && (
            <p className="text-xs text-gray-400">
              Nenhuma atividade cadastrada neste bloco.
            </p>
          )}
        </div>
      </div>
    )
  }

  const previewUrl = previewEvidence
    ? `/api/evidencias/${previewEvidence.evidenceFileId}/conteudo`
    : ""

  return (
    <main className="min-h-screen bg-gray-50 p-6">
      <Modal
        open={modal.open}
        title={modal.title}
        message={modal.message}
        variant={modal.variant}
        onClose={closeModal}
      />

      {previewEvidence && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-xl max-w-3xl w-full h-[80vh] mx-4 flex flex-col">
            <div className="flex items-center justify-between px-4 py-3 border-b gap-3">
              <div className="flex flex-col min-w-0">
                <span className="text-sm font-semibold text-gray-800 break-words">
                  {previewEvidence.originalName}
                </span>
                <span className="text-[11px] text-gray-500">
                  {previewEvidence.sizeBytes
                    ? `${(previewEvidence.sizeBytes / (1024 * 1024)).toFixed(
                        2
                      )} MB`
                    : "tamanho não informado"}
                </span>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  type="button"
                  className="text-xs px-3 py-1.5 rounded-full border hover:bg-gray-50"
                  onClick={() => setPreviewEvidence(null)}
                >
                  Fechar
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-hidden">
              <iframe
                src={previewUrl}
                className="w-full h-full rounded-b-2xl"
              />
            </div>
          </div>
        </div>
      )}

      {evidenceModal.open && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full mx-4 p-4 space-y-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h2 className="text-sm font-semibold text-gray-800">
                  {evidenceModal.mode === "attachRequired"
                    ? "Anexar comprovante obrigatório"
                    : "Gerenciar comprovante"}
                </h2>
                <p className="mt-1 text-[11px] text-gray-600">
                  {evidenceModal.mode === "attachRequired"
                    ? "Para lançar pontuação neste item, é obrigatório anexar pelo menos um comprovante. Você pode reutilizar um arquivo já enviado ou enviar um novo."
                    : "Você pode alterar o comprovante deste item reutilizando um arquivo já enviado ou enviando um novo."}
                </p>
              </div>
              <button
                type="button"
                className="text-xs px-2 py-1 rounded-full border hover:bg-gray-50"
                onClick={() => {
                  closeEvidenceModal()
                }}
              >
                Fechar
              </button>
            </div>

            <div className="space-y-2">
              <label className="block text-[11px] text-gray-500 mb-1">
                Enviar novo arquivo (PDF ou imagem &lt;= 5MB)
              </label>
              <input
                type="file"
                accept=".pdf,image/jpeg,image/jpg,image/png"
                className="block w-full text-xs border rounded-xl px-2 py-1.5 bg-white"
                onChange={e => {
                  const file = e.target.files?.[0] ?? null
                  if (file) {
                    handleUploadEvidenceFromModal(file)
                    e.target.value = ""
                  }
                }}
                disabled={uploadingItemId === evidenceModal.itemId}
              />
              {uploadingItemId === evidenceModal.itemId && (
                <p className="text-[11px] text-gray-500">
                  Enviando arquivo, aguarde...
                </p>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium text-gray-700">
                  Arquivos já enviados
                </span>
              </div>
              <div className="border rounded-xl max-h-56 overflow-y-auto">
                {evidenceModal.loading && (
                  <p className="text-[11px] text-gray-500 p-3">
                    Carregando arquivos...
                  </p>
                )}

                {!evidenceModal.loading &&
                  evidenceModal.files.length === 0 && (
                    <p className="text-[11px] text-gray-500 p-3">
                      Você ainda não enviou arquivos de evidência.
                    </p>
                  )}

                {!evidenceModal.loading &&
                  evidenceModal.files.length > 0 && (
                    <ul className="divide-y text-xs">
                      {evidenceModal.files.map(file => (
                        <li key={file.evidenceFileId} className="p-2.5 space-y-1">
                          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                            <div className="flex flex-col min-w-0">
                              <span className="font-medium break-all">
                                {file.originalName}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              <button
                                type="button"
                                className="inline-flex items-center justify-center gap-1 text-[11px] px-3 py-1 rounded-full border border-gray-300 hover:bg-gray-50"
                                onClick={() =>
                                  setPreviewEvidence({
                                    evidenceFileId: file.evidenceFileId,
                                    originalName: file.originalName,
                                    url: file.url,
                                    mimeType: file.mimeType,
                                    sizeBytes: file.sizeBytes
                                  })
                                }
                              >
                                <EyeIcon className="w-3 h-3" />
                                <span>Visualizar</span>
                              </button>
                              <button
                                type="button"
                                className="inline-flex items-center justify-center gap-1 text-[11px] px-3 py-1 rounded-full border border-gray-300 hover:bg-gray-50"
                                onClick={() =>
                                  handleReuseEvidenceFromModal(file.evidenceFileId)
                                }
                                disabled={uploadingItemId === evidenceModal.itemId}
                              >
                                <FileSwapIcon className="w-3 h-3" />
                                <span>Usar este comprovante</span>
                              </button>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-5xl mx-auto space-y-6">
        <header className="flex flex-wrap gap-3 justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold">
              Pontuação do Processo {id ? `#${id}` : ""}
            </h1>
            <p className="text-sm text-gray-600">
              Para cada atividade, informe a quantidade (quando não houver limite)
              ou os pontos finais (quando houver pontuação máxima) e anexe os
              comprovantes.
            </p>
          </div>
          <div className="flex gap-2">
            <Link
              href={id ? `/docente/processos/${id}` : "/docente/processos"}
              className="px-4 py-2 rounded-2xl border text-sm hover:bg-gray-50"
            >
              Voltar aos detalhes do processo
            </Link>
          </div>
        </header>

        {loading && (
          <div className="bg-white border rounded-2xl p-4 shadow-sm">
            <p className="text-sm text-gray-600">
              Carregando estrutura de pontuação...
            </p>
          </div>
        )}

        {!loading && error && (
          <div className="bg-red-50 border border-red-200 text-red-800 text-sm rounded-2xl p-4">
            {error}
          </div>
        )}

        {!loading && !error && estrutura && (
          <>
            <section className="rounded-2xl border bg-white p-4 shadow-sm flex flex-wrap gap-3 justify-between items-center">
              <div className="space-y-1 text-sm">
                <div>
                  <span className="font-medium">Processo:</span>{" "}
                  {estrutura.processId}
                </div>
                <div>
                  <span className="font-medium">Tipo:</span>{" "}
                  {estrutura.type === "PROGRESSAO"
                    ? "Progressão"
                    : "Promoção"}
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">Situação:</span>
                  <span
                    className={
                      "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium " +
                      badgeColor(estrutura.status)
                    }
                  >
                    {statusLabel(estrutura.status)}
                  </span>
                </div>
              </div>
              {!canEditScores && (
                <p className="text-[11px] text-gray-500 max-w-xs">
                  A pontuação só pode ser alterada quando o processo está nos
                  status <span className="font-medium">DRAFT</span>,{" "}
                  <span className="font-medium">RETURNED</span> ou{" "}
                  <span className="font-medium">REJECTED</span>. No momento, os
                  campos estão somente para leitura.
                </p>
              )}
            </section>

            <section className="space-y-4">
              {treeRoots.length === 0 && (
                <div className="bg-white border rounded-2xl p-4 shadow-sm text-sm text-gray-500">
                  Nenhuma estrutura de pontuação definida para esta tabela.
                </div>
              )}

              {treeRoots.map(root => renderNode(root))}
            </section>
          </>
        )}
      </div>
    </main>
  )
}
