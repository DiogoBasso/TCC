import Form from "./Form"

export default function AbrirProcessoPage() {
  return (
    <main className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-3xl mx-auto">
        <Form />
      </div>
    </main>
  )
}
