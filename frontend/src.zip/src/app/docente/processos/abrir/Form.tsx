"use client"

import { useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import Modal from "@/components/Modal"

type ProcessType = "PROGRESSAO" | "PROMOCAO"

type ApiResponse<T> = {
  status: string
  message: string
  data: T | null
}

type CreatedProcess = {
  processId: number
}

type ModalVariant = "success" | "error" | "info"

type ModalState = {
  open: boolean
  title: string
  message: string
  variant: ModalVariant
}

function todayISO() {
  return new Date().toISOString().slice(0, 10)
}

export default function Form() {
  const router = useRouter()

  const [tipo, setTipo] = useState<ProcessType>("PROGRESSAO")
  const [campus, setCampus] = useState("Santa Rosa")
  const [cidade, setCidade] = useState("Santa Rosa")
  const [estado, setEstado] = useState("RS")
  const [intersticioInicio, setIntersticioInicio] = useState(todayISO())
  const [intersticioFim, setIntersticioFim] = useState("")
  const [classeOrigem, setClasseOrigem] = useState("A")
  const [nivelOrigem, setNivelOrigem] = useState("1")
  const [classeDestino, setClasseDestino] = useState("B")
  const [nivelDestino, setNivelDestino] = useState("1")

  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [modal, setModal] = useState<ModalState>({
    open: false,
    title: "",
    message: "",
    variant: "info"
  })

  const cidadeUF = useMemo(
    () => `${cidade} - ${estado}`,
    [cidade, estado]
  )

  function openModal(payload: Omit<ModalState, "open">) {
    setModal({
      open: true,
      ...payload
    })
  }

  function closeModal() {
    setModal(prev => ({
      ...prev,
      open: false
    }))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitting(true)
    setError(null)

    try {
      const payload = {
        patchUsuario: null,
        processo: {
          tipo,
          campus,
          cidadeUF,
          dataEmissaoISO: new Date().toISOString(),
          intersticioInicioISO: intersticioInicio,
          intersticioFimISO: intersticioFim,
          classeOrigem,
          nivelOrigem,
          classeDestino,
          nivelDestino
        }
      }

      const r = await fetch("/api/processos/abrir", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify(payload)
      })

      const json = (await r.json().catch(() => null)) as ApiResponse<CreatedProcess>

      if (!r.ok) {
        setError(json?.message || "Erro ao abrir processo")
        return
      }

      const processId = (json?.data as any)?.processId

      if (processId) {
        openModal({
          title: "Processo aberto",
          message: `Processo nº ${processId} aberto com sucesso. Você poderá gerar o requerimento quando completar o interstício.`,
          variant: "success"
        })

        setTimeout(() => {
          router.push(`/docente/processos/${processId}`)
        }, 600)
      } else {
        openModal({
          title: "Processo aberto",
          message: "Processo aberto com sucesso.",
          variant: "success"
        })
        setTimeout(() => {
          router.push("/docente/processos")
        }, 600)
      }
    } catch (e: any) {
      openModal({
        title: "Erro inesperado",
        message: e?.message || "Ocorreu um erro ao abrir o processo.",
        variant: "error"
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <>
      <Modal
        open={modal.open}
        title={modal.title}
        message={modal.message}
        variant={modal.variant}
        onClose={closeModal}
      />

      <div className="bg-white border rounded-2xl shadow-sm p-6 space-y-6">
        <header className="space-y-1">
          <h1 className="text-xl font-semibold">Abrir novo processo</h1>
          <p className="text-sm text-gray-600">
            Informe os dados do interstício e da movimentação desejada para iniciar o processo.
          </p>
        </header>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-800 text-sm rounded-xl p-3">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Tipo e campus */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1 text-sm">
              <label className="font-medium">Tipo de processo</label>
              <select
                className="border rounded-xl px-3 py-2 text-sm"
                value={tipo}
                onChange={e => setTipo(e.target.value as ProcessType)}
              >
                <option value="PROGRESSAO">Progressão</option>
                <option value="PROMOCAO">Promoção</option>
              </select>
            </div>

            <div className="flex flex-col gap-1 text-sm">
              <label className="font-medium">Campus</label>
              <input
                className="border rounded-xl px-3 py-2 text-sm"
                value={campus}
                onChange={e => setCampus(e.target.value)}
              />
            </div>
          </div>

          {/* Cidade / UF */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="md:col-span-2 flex flex-col gap-1 text-sm">
              <label className="font-medium">Cidade</label>
              <input
                className="border rounded-xl px-3 py-2 text-sm"
                value={cidade}
                onChange={e => setCidade(e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-1 text-sm">
              <label className="font-medium">UF</label>
              <input
                className="border rounded-xl px-3 py-2 text-sm"
                value={estado}
                maxLength={2}
                onChange={e => setEstado(e.target.value.toUpperCase())}
              />
            </div>
          </div>

          {/* Interstício */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1 text-sm">
              <label className="font-medium">Início do interstício</label>
              <input
                type="date"
                className="border rounded-xl px-3 py-2 text-sm"
                value={intersticioInicio}
                onChange={e => setIntersticioInicio(e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-1 text-sm">
              <label className="font-medium">Fim do interstício</label>
              <input
                type="date"
                className="border rounded-xl px-3 py-2 text-sm"
                value={intersticioFim}
                onChange={e => setIntersticioFim(e.target.value)}
              />
            </div>
          </div>

          {/* Movimentação */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h2 className="text-sm font-semibold text-gray-700">Origem</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1 text-sm">
                  <label>Classe</label>
                  <input
                    className="border rounded-xl px-3 py-2 text-sm"
                    value={classeOrigem}
                    onChange={e => setClasseOrigem(e.target.value.toUpperCase())}
                  />
                </div>
                <div className="flex flex-col gap-1 text-sm">
                  <label>Nível</label>
                  <input
                    className="border rounded-xl px-3 py-2 text-sm"
                    value={nivelOrigem}
                    onChange={e => setNivelOrigem(e.target.value)}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h2 className="text-sm font-semibold text-gray-700">Destino</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1 text-sm">
                  <label>Classe</label>
                  <input
                    className="border rounded-xl px-3 py-2 text-sm"
                    value={classeDestino}
                    onChange={e => setClasseDestino(e.target.value.toUpperCase())}
                  />
                </div>
                <div className="flex flex-col gap-1 text-sm">
                  <label>Nível</label>
                  <input
                    className="border rounded-xl px-3 py-2 text-sm"
                    value={nivelDestino}
                    onChange={e => setNivelDestino(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Botões */}
          <div className="flex gap-3">
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 rounded-2xl bg-black text-white text-sm font-medium disabled:opacity-50 hover:opacity-90"
            >
              {submitting ? "Abrindo processo..." : "Abrir processo"}
            </button>
          </div>
        </form>
      </div>
    </>
  )
}
